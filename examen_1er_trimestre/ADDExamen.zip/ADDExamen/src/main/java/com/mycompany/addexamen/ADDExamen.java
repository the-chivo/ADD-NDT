/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.addexamen;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Alumnos
 */
public class ADDExamen {
    
    static private AlumnoDAO alumnoDAO;
    static private String alumnosTablaQuery = "CREATE TABLE IF NOT EXISTS Alumnos (" +
            "ID SERIAL PRIMARY KEY, " +
            "nombre VARCHAR(100), " +
            "curso INT" +
            ")";

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        int opcion = 0;
        String url = ConfiguracionXML.getUrl();
        String user = ConfiguracionXML.getUsuario();
        String pass = ConfiguracionXML.getPassword();
        
        Connection conn = null;
        Statement stm = null;
        
        try{
            conn = DriverManager.getConnection(url, user, pass);
            alumnoDAO = new AlumnoDAO(conn);
            stm = conn.createStatement();
            stm.executeUpdate(alumnosTablaQuery);
        }catch(SQLException e){
            e.printStackTrace(); 
            System.out.println("Error en la base de datos: " + e.getMessage());
        }
        
        do{
            
            System.out.println("1. Listar todos los datos de todos los usuarios");
            System.out.println("2. Añadir un nuevo usuario");
            System.out.println("3. Eliminar usuario proporcionando su id");
            System.out.println("4. Listar unicamente el nombre de los usuarios de un curso especifico");
            System.out.println("0. Salir");
            opcion = sc.nextInt();
            switch(opcion){
                
                case 1:
                    listAllStudentData();
                    break;
                case 2:
                    addStudent();
                    break;
                case 3:
                    deleteStudent();
                    break;
                case 4:
                    listNameByCurse();
            }
        }while(opcion != 0);
    }
    
    
    
    private static void addStudent(){
        
        Scanner sc = new Scanner(System.in);
        String nombre;
        int curso = 0;
        System.out.println("Introduzca el nombre del alumno");
        nombre = sc.nextLine();
        System.out.println("Introduzca el curso del alumno");
        curso = sc.nextInt();
        if(curso == 1 || curso == 2){
            
            Alumno alumno = new Alumno(nombre.toLowerCase(), curso); //El lowerCase es para evitar inyecciones
            alumnoDAO.add(alumno);
            System.out.println("Has añadido a " + nombre + " con curso " + curso);
        }
        else{System.out.println("El curso solo puede ser 1 o 2");}
    }
    
    private static void deleteStudent(){
        
        Scanner sc = new Scanner(System.in);
        int id;
        System.out.println("Introduzca la id del alumno que desea eliminar");
        id = sc.nextInt();
        alumnoDAO.delete(id);
    }
    
    private static void listAllStudentData(){
        
        List<Alumno> alumnos = alumnoDAO.listAllData();
        for(Alumno alumno : alumnos){                       
                System.out.println("ID: " + alumno.getId() + " Nombre: " + alumno.getNombre() + " Curso: " + alumno.getCurso());
            }
                 
    }
    
    private static void listNameByCurse(){
        
        Scanner sc = new Scanner(System.in);
        int curso;
        System.out.println("Introduca el curso de los alumnos que desea listar");
        curso = sc.nextInt();
        if(curso == 1 || curso == 2){
            List<Alumno> alumnos = alumnoDAO.listAlumnosByCorse(curso);
            for(Alumno alumno : alumnos){                       
                    System.out.println("Nombre: " + alumno.getNombre());
                }  
        }
        else{
            System.out.println("El curso selecionado solo puede ser 1 o 2");
        }        
    }
    
}
