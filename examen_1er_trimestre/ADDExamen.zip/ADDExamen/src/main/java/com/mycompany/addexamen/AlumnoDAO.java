/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.addexamen;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Alumnos
 */
public class AlumnoDAO {
    
    private Connection connection;
    
    public AlumnoDAO(Connection connection){
        
        this.connection = connection; 
    }
    
    public void add(Alumno alumno) {
        String sql = "INSERT INTO alumnos (nombre, curso) VALUES (?, ?)";
        try {
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, alumno.getNombre());
            statement.setInt(2, alumno.getCurso());           
            statement.executeUpdate();
        } catch (SQLException sqle) {
            System.out.println("No se ha podido conectar con el servidor de base de datos. Comprueba que los datos son correctos y que el servidor se ha iniciado");
            sqle.printStackTrace();
        }
    }
    
    public void delete(int id){
        String sql = "DELETE FROM alumnos WHERE id = ?";
        try {
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, id);
            statement.executeUpdate();
    
        } catch (SQLException sqle) {
            System.out.println("No se ha podido conectar con el servidor de base de datos. Comprueba que los datos son correctos y que el servidor se ha iniciado");
            sqle.printStackTrace();
        }
    }
    
    public ArrayList<Alumno> listAllData(){
        
        String sql = "SELECT * FROM alumnos ORDER BY id";
        
        ArrayList<Alumno> alumnos = new ArrayList<>();
        try {
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                String nombre = resultSet.getString("nombre");                
                int curso = resultSet.getInt("curso");

                Alumno alumno = new Alumno(nombre, curso);
                alumno.setId(resultSet.getInt("id"));
                alumnos.add(alumno);
            }
        } catch (SQLException sqle) {
            System.out.println("No se ha podido conectar con el servidor de base de datos. Comprueba que los datos son correctos y que el servidor se ha iniciado");
            sqle.printStackTrace();
        }
    return alumnos;
    }
    
    public ArrayList<Alumno> listAlumnosByCorse(int cursoInput){
        
        String sql = "SELECT * FROM alumnos WHERE curso = ?";
        ArrayList<Alumno> alumnos = new ArrayList<>();
        try {
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, cursoInput); // asignamos el parámetro id
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                String nombre = resultSet.getString("nombre");              
                int curso = resultSet.getInt("curso");
                Alumno alumno = new Alumno(nombre, curso);
                alumno.setId(resultSet.getInt("id"));
                alumnos.add(alumno);
            }
        } catch (SQLException sqle) {
            System.out.println("No se ha podido conectar con el servidor de base de datos. Comprueba que los datos son correctos y que el servidor se ha iniciado");
            sqle.printStackTrace();
        }
    return alumnos;
    }
    
}
